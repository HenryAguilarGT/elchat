/*!
 * 
 *    @license KRISP TECHNOLOGIES, INC
 *
 *   KRISP TECHNOLOGIES, INC
 *   __________________
 *
 *   [2018] - [2022] Krisp Technologies, Inc
 *   All Rights Reserved.
 *
 *   NOTICE: By accessing this programming code, you acknowledge that you have read, understood, and agreed to the User Agreement available at
 *   https://krisp.ai/terms-of-use.
 *
 *   Please note that ALL information contained herein is and remains the property of Krisp Technologies, Inc., and its affiliates or assigns, if any. The intellectual property
 *   contained herein is proprietary to Krisp Technologies, Inc. and may be covered by pending and granted U.S. and Foreign Patents, and is further protected by
 *   copyright, trademark and/or other forms of intellectual property protection.
 *   Dissemination of this information or reproduction of this material IS STRICTLY FORBIDDEN.
 *
 */
function a0_0x5d75(){const _0x2189de=['Krisp\x20is\x20not\x20connected\x20to\x20any\x20valid\x20stream,\x20please\x20call\x20Krisp.connect(stream)\x20first','initialized','Platform\x20not\x20supported','connected','17562636SYvNXc','Currently\x20only\x20Chrome,\x20Firefox\x20and\x20Edge\x20browsers\x20are\x20supported','webkitAudioContext','3785586HSeJzE','Invalid\x20init\x20option','1668808EsfRqs','Invalid\x20state','509740eGCQOI','FilterFactory','6eBtUqz','enabled','not_initialized','full-band','264636wgoiEM','narrow-band','130592yQAlcf','freeze','35RNdKjN','656468lANcPZ','disconnected','AudioContext','Invalid\x20MediaStream','Krisp\x20already\x20initialized,\x20first\x20call\x20krisp.destroy()'];a0_0x5d75=function(){return _0x2189de;};return a0_0x5d75();}const a0_0x974f5b=a0_0x1511;function a0_0x1511(_0xf7ffb0,_0x448e98){const _0x5d75ae=a0_0x5d75();return a0_0x1511=function(_0x1511fc,_0x5e0a6d){_0x1511fc=_0x1511fc-0x122;let _0x30bb41=_0x5d75ae[_0x1511fc];return _0x30bb41;},a0_0x1511(_0xf7ffb0,_0x448e98);}(function(_0xd6b4f7,_0x19eb59){const _0x1f19e1=a0_0x1511,_0x4a7cc4=_0xd6b4f7();while(!![]){try{const _0x35446c=-parseInt(_0x1f19e1(0x12d))/0x1+-parseInt(_0x1f19e1(0x125))/0x2+-parseInt(_0x1f19e1(0x123))/0x3+parseInt(_0x1f19e1(0x132))/0x4*(parseInt(_0x1f19e1(0x131))/0x5)+-parseInt(_0x1f19e1(0x129))/0x6*(-parseInt(_0x1f19e1(0x127))/0x7)+-parseInt(_0x1f19e1(0x12f))/0x8+parseInt(_0x1f19e1(0x13b))/0x9;if(_0x35446c===_0x19eb59)break;else _0x4a7cc4['push'](_0x4a7cc4['shift']());}catch(_0x17c126){_0x4a7cc4['push'](_0x4a7cc4['shift']());}}}(a0_0x5d75,0xc24a9),void 0x0!==window[a0_0x974f5b(0x134)]?window[a0_0x974f5b(0x134)]:void 0x0!==window[a0_0x974f5b(0x122)]&&window[a0_0x974f5b(0x122)],Object[a0_0x974f5b(0x130)]({'not_init':'Not\x20initialized,\x20first\x20run\x20Krisp.init()','no_support':a0_0x974f5b(0x139),'browser_no_support':a0_0x974f5b(0x13c),'already_init':a0_0x974f5b(0x136),'invalid_stream':a0_0x974f5b(0x135),'invalid_state':a0_0x974f5b(0x126),'invalid_init_options':a0_0x974f5b(0x124),'not_connected':a0_0x974f5b(0x137)}));const i=Object[a0_0x974f5b(0x130)]({'initialized':a0_0x974f5b(0x138),'not_initialized':a0_0x974f5b(0x12b),'connected':a0_0x974f5b(0x13a),'disconnected':a0_0x974f5b(0x133),'enabled':a0_0x974f5b(0x12a),'disabled':'disabled'});Object['freeze']({'model_8':a0_0x974f5b(0x12e),'model_16':'wide-band','model_32':a0_0x974f5b(0x12c),'model_vad':'vad'}),i[a0_0x974f5b(0x12b)],window[a0_0x974f5b(0x128)]=FilterFactory;